import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { fetchStudentPortal } from '../../api/api';
import { useAuth } from '../../core/auth/useAuth';
import AnnouncementsList from './components/AnnouncementsList';
import EmptyState from './components/EmptyState';
import FeedbackList from './components/FeedbackList';
import SubjectCard from './components/SubjectCard';
import SubjectPage from './components/SubjectPage';
import { resolveSubjectImage } from './utils/subjectVisuals';
import './studentPortal.css';

const FEEDBACK_CATEGORY_LABELS = {
  academic: 'أكاديمي',
  moral: 'سلوك',
  behavior: 'سلوك',
  idfk: 'أخرى',
};

function BellIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" className="h-[18px] w-[18px]" aria-hidden="true">
      <path d="M12 3a4 4 0 0 0-4 4v2.2c0 .8-.2 1.6-.7 2.3L6 13.4v1.1h12v-1.1l-1.3-1.9a4.2 4.2 0 0 1-.7-2.3V7a4 4 0 0 0-4-4Z" stroke="currentColor" strokeWidth="1.4" />
      <path d="M10 17a2 2 0 0 0 4 0" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

const mapFeedbackCategory = (value) => FEEDBACK_CATEGORY_LABELS[String(value || '').trim().toLowerCase()] || value || 'أخرى';

export default function StudentPortalPage() {
  const navigate = useNavigate();
  const { token, user, logout } = useAuth();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [portalData, setPortalData] = useState(null);
  const [activeSubjectId, setActiveSubjectId] = useState(null);

  useEffect(() => {
    let active = true;

    const loadPortal = async () => {
      try {
        setLoading(true);
        setError('');
        const payload = await fetchStudentPortal(token);
        if (!active) {
          return;
        }

        const normalizedSubjects = (payload.subjects || []).map((subject) => ({
          ...subject,
          image: resolveSubjectImage(subject.name),
          feedbackItems: (subject.feedbackItems || []).map((item) => ({
            ...item,
            category: mapFeedbackCategory(item.category),
          })),
        }));

        setPortalData({
          ...payload,
          subjects: normalizedSubjects,
          recentFeedback: (payload.recentFeedback || []).map((item) => ({
            ...item,
            category: mapFeedbackCategory(item.category),
          })),
        });
      } catch (loadError) {
        if (active) {
          setError(loadError?.message || 'تعذر تحميل البوابة الأكاديمية.');
          setPortalData(null);
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    if (token) {
      loadPortal();
    } else {
      setLoading(false);
    }

    return () => {
      active = false;
    };
  }, [token]);

  const subjects = portalData?.subjects || [];

  const selectedSubject = useMemo(() => {
    if (!activeSubjectId) return null;
    return subjects.find((item) => item.id === activeSubjectId) || null;
  }, [activeSubjectId, subjects]);

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  const studentName = portalData?.student?.name || user?.name || 'الطالب';
  const className = portalData?.student?.className || user?.classes?.[0] || '';
  const avatarUrl = portalData?.student?.avatarUrl || user?.profilePicture || '';
  const notificationsCount = Number((portalData?.recentFeedback || []).length || 0);
  const weeklySnapshot = portalData?.weeklySnapshot || null;

  if (activeSubjectId && selectedSubject) {
    return (
      <SubjectPage
        subject={selectedSubject}
        allSubjects={subjects}
        subjectDetails={{}}
        recentFeedback={portalData?.recentFeedback || []}
        onBack={() => setActiveSubjectId(null)}
        onSwitch={setActiveSubjectId}
      />
    );
  }

  const announcements = (portalData?.announcements || []).map((item) => ({
    id: item.id,
    title: item.title,
    description: item.description,
    date: item.date,
    type: item.subject || 'إعلان',
    actionLabel: 'عرض',
  }));

  return (
    <main dir="rtl" className="hs-theme min-h-screen bg-[var(--hs-bg-base)]">
      <div className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6 lg:px-12">
        <header className="mb-10 flex items-center justify-between gap-4">
          <div>
            <h1 className="hs-display text-[28px] font-semibold leading-tight text-[var(--hs-neutral-900)]">مرحباً، {studentName}</h1>
            <p className="mt-1 text-[13px] text-[var(--hs-neutral-500)]">{className ? `الصف ${className}` : 'الصف غير محدد'} · البوابة الأكاديمية</p>
          </div>

          <div className="flex items-center gap-2">
            <Link
              to="/student/schedule"
              className="hs-interactive inline-flex h-10 items-center justify-center rounded-[6px] border border-[var(--hs-primary-600)] bg-[var(--hs-primary-600)] px-4 text-[13px] font-medium text-white hover:bg-[var(--hs-primary-700)]"
            >
              الجدول الأسبوعي
            </Link>

            <button
              type="button"
              aria-label="الإشعارات"
              className="hs-interactive relative inline-flex h-10 w-10 items-center justify-center rounded-[6px] border border-[var(--hs-border-subtle)] bg-[var(--hs-bg-base)] text-[var(--hs-neutral-600)] hover:bg-[var(--hs-bg-subtle)]"
            >
              <BellIcon />
              {notificationsCount > 0 && (
                <span className="absolute -left-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-[var(--hs-danger-600)] text-[10px] font-semibold text-white">
                  {notificationsCount > 9 ? '9+' : notificationsCount}
                </span>
              )}
            </button>

            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt={studentName}
                className="h-10 w-10 rounded-full border border-[var(--hs-border-default)] object-cover"
              />
            ) : null}

            <button
              type="button"
              onClick={handleLogout}
              className="hs-interactive hidden h-10 items-center justify-center rounded-[6px] border border-[var(--hs-border-default)] px-4 text-[13px] font-medium text-[var(--hs-neutral-700)] hover:bg-[var(--hs-bg-subtle)] sm:inline-flex"
            >
              خروج
            </button>
          </div>
        </header>

        {error ? (
          <p className="mb-6 rounded-[6px] border border-[var(--hs-danger-100)] bg-[var(--hs-danger-100)] px-4 py-3 text-[13px] text-[var(--hs-danger-600)]">
            {error}
          </p>
        ) : null}

        {weeklySnapshot ? (
          <section className="hs-surface-card mb-8 p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-[18px] font-semibold text-[var(--hs-neutral-800)]">AI Weekly Snapshot</h2>
              <span className="text-[12px] text-[var(--hs-neutral-500)]">
                {weeklySnapshot.academicDirection} · {weeklySnapshot.riskStatus} risk
              </span>
            </div>
            <p className="mt-3 text-[13px] text-[var(--hs-neutral-600)]">{weeklySnapshot.attendancePattern}</p>
            <p className="mt-1 text-[13px] text-[var(--hs-neutral-600)]">{weeklySnapshot.behaviorNote}</p>
            <p className="mt-1 text-[13px] text-[var(--hs-neutral-600)]">
              Parent engagement: {weeklySnapshot.parentEngagementStatus}
            </p>
          </section>
        ) : null}

        <section>
          <div className="mb-4 flex items-baseline justify-between gap-3">
            <h2 className="text-[18px] font-semibold text-[var(--hs-neutral-800)]">المواد الدراسية</h2>
            <span className="text-[13px] text-[var(--hs-neutral-500)]">{subjects.length} مواد</span>
          </div>

          {loading ? (
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <div className="skeleton h-[170px]" />
              <div className="skeleton h-[170px]" />
              <div className="skeleton h-[170px]" />
              <div className="skeleton h-[170px]" />
            </div>
          ) : !subjects.length ? (
            <div className="hs-surface-card p-5">
              <EmptyState title="لا توجد مواد مخصصة" description="لم يتم إسناد مواد دراسية لهذا الطالب بعد." compact />
            </div>
          ) : (
            <div className="hs-scroll-x overflow-x-auto pb-2">
              <div className="flex gap-3" style={{ width: 'max-content' }}>
                {subjects.map((subject) => (
                  <SubjectCard key={subject.id} subject={subject} onClick={() => setActiveSubjectId(subject.id)} />
                ))}
              </div>
            </div>
          )}
        </section>

        <section className="mt-10 grid gap-5 xl:grid-cols-2">
          <FeedbackList items={portalData?.recentFeedback || []} />
          <AnnouncementsList items={announcements} featured={null} />
        </section>
      </div>
    </main>
  );
}
