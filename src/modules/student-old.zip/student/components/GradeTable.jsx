import EmptyState from './EmptyState';
import { formatEnglishDate, formatEnglishNumber } from '../utils/format';

const calcAveragePercent = (rows) => {
  if (!rows.length) return 0;

  const totalScore = rows.reduce((sum, row) => sum + Number(row.score || 0), 0);
  const totalOutOf = rows.reduce((sum, row) => sum + Number(row.outOf || 0), 0);
  if (!totalOutOf) return 0;

  return (totalScore / totalOutOf) * 100;
};

export default function GradeTable({ rows = [] }) {
  const averagePercent = calcAveragePercent(rows);
  const averageDisplay = formatEnglishNumber(averagePercent, 1);

  return (
    <section className="space-y-4">
      <div className="hs-soft-surface p-4">
        <div className="mb-2 flex items-center justify-between gap-3">
          <p className="text-[13px] text-[var(--hs-neutral-500)]">المتوسط العام</p>
          <p className="text-[20px] font-semibold text-[var(--hs-neutral-900)]">{averageDisplay}%</p>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-[var(--hs-bg-muted)]">
          <span
            className="block h-full rounded-full bg-[var(--hs-primary-600)] transition-all duration-200 ease-out"
            style={{ width: `${Math.max(0, Math.min(100, averagePercent))}%` }}
          />
        </div>
      </div>

      {!rows.length ? (
        <EmptyState title="لا توجد درجات" description="سيتم عرض نتائج التقييم فور اعتمادها." compact />
      ) : (
        <div className="overflow-x-auto rounded-[6px] border border-[var(--hs-border-subtle)]">
          <table className="w-full min-w-[540px] border-collapse">
            <thead className="bg-[var(--hs-bg-subtle)] text-[11px] font-semibold uppercase tracking-[0.06em] text-[var(--hs-neutral-500)]">
              <tr>
                <th scope="col" className="px-4 py-3 text-right">التقييم</th>
                <th scope="col" className="px-4 py-3 text-right">الدرجة</th>
                <th scope="col" className="px-4 py-3 text-right">من</th>
                <th scope="col" className="px-4 py-3 text-right">التاريخ</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id} className="hs-interactive border-t border-[var(--hs-border-subtle)] text-[14px] hover:bg-[var(--hs-bg-subtle)]">
                  <td className="px-4 py-3 text-[var(--hs-neutral-700)]">{row.assessment}</td>
                  <td className="px-4 py-3 font-semibold text-[var(--hs-neutral-900)]">
                    {formatEnglishNumber(row.score)}
                  </td>
                  <td className="px-4 py-3 text-[var(--hs-neutral-600)]">
                    {formatEnglishNumber(row.outOf)}
                  </td>
                  <td className="px-4 py-3 text-[var(--hs-neutral-500)]">{formatEnglishDate(row.date)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

