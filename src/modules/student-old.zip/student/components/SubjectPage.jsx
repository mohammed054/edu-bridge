﻿import { useEffect, useMemo, useRef, useState } from 'react';
import EmptyState from './EmptyState';
import GradeTable from './GradeTable';
import Sidebar from './Sidebar';
import Tabs from './Tabs';
import { formatEnglishDate, formatEnglishDateTime, formatEnglishNumber } from '../utils/format';

const TAB_OPTIONS = [
  { key: 'posts', label: 'المنشورات' },
  { key: 'homework', label: 'الواجبات' },
  { key: 'grades', label: 'الدرجات' },
];

const HOMEWORK_STATUS_STYLES = {
  مكتمل: 'bg-[var(--hs-success-100)] text-[var(--hs-success-600)]',
  'غير مكتمل': 'bg-[var(--hs-danger-100)] text-[var(--hs-danger-600)]',
};

function BackIcon() {
  return (
    <svg viewBox="0 0 20 20" fill="none" className="h-4 w-4" aria-hidden="true">
      <path d="m13 4 6 6-6 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ChevronIcon() {
  return (
    <svg viewBox="0 0 20 20" fill="none" className="h-4 w-4" aria-hidden="true">
      <path d="m4 7 6 6 6-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function SubjectSwitcher({ current, allSubjects, onSwitch }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="hs-interactive inline-flex h-9 items-center gap-2 rounded-[6px] border border-[var(--hs-border-default)] bg-[var(--hs-bg-base)] px-3 text-[13px] font-medium text-[var(--hs-neutral-700)] hover:bg-[var(--hs-bg-subtle)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--hs-primary-500)] focus-visible:ring-offset-2 active:scale-[0.98]"
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <span className="max-w-[140px] truncate">{current.name}</span>
        <ChevronIcon />
      </button>

      {open && (
        <div
          role="listbox"
          aria-label="اختر مادة"
          className="absolute start-0 top-full z-30 mt-1 min-w-[200px] overflow-hidden rounded-[6px] border border-[var(--hs-border-default)] bg-[var(--hs-bg-base)] shadow-[var(--hs-shadow-soft)]"
          style={{ animation: 'hs-fade-up 150ms ease-out both' }}
        >
          {allSubjects.map((s) => (
            <button
              key={s.id}
              type="button"
              role="option"
              aria-selected={s.id === current.id}
              onClick={() => {
                onSwitch(s.id);
                setOpen(false);
              }}
              className={`hs-interactive flex w-full items-center gap-3 px-4 py-3 text-right text-[13px] hover:bg-[var(--hs-bg-subtle)] focus-visible:outline-none focus-visible:bg-[var(--hs-bg-subtle)] ${
                s.id === current.id
                  ? 'bg-[var(--hs-primary-050)] font-medium text-[var(--hs-primary-700)]'
                  : 'text-[var(--hs-neutral-700)]'
              }`}
            >
              <img
                src={s.image}
                alt=""
                aria-hidden="true"
                className="h-7 w-7 rounded-[4px] border border-[var(--hs-border-subtle)] object-contain p-0.5"
              />
              <span>{s.name}</span>
              {s.id === current.id && (
                <span className="me-auto ms-2 h-1.5 w-1.5 rounded-full bg-[var(--hs-primary-500)]" />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function SubjectPage({ subject, allSubjects, subjectDetails, recentFeedback, onBack, onSwitch }) {
  const [activeTab, setActiveTab] = useState('posts');
  const [expandedPosts, setExpandedPosts] = useState({});

  useEffect(() => {
    setActiveTab('posts');
    setExpandedPosts({});
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [subject?.id]);

  const handleSwitch = (id) => {
    onSwitch(id);
  };

  const averageGrade = useMemo(() => {
    const grades = subject?.grades || [];
    if (!grades.length) return 0;
    const totalScore = grades.reduce((sum, g) => sum + Number(g.score || 0), 0);
    const totalOutOf = grades.reduce((sum, g) => sum + Number(g.outOf || 0), 0);
    return totalOutOf ? (totalScore / totalOutOf) * 100 : 0;
  }, [subject?.grades]);

  const togglePost = (postId) => {
    setExpandedPosts((cur) => ({ ...cur, [postId]: !cur[postId] }));
  };

  const renderPosts = () => {
    const posts = subject.posts || [];
    if (!posts.length) {
      return <EmptyState title="لا توجد منشورات" description="لا توجد منشورات لهذه المادة حالياً." compact />;
    }
    return (
      <div className="space-y-3">
        {posts.map((post) => {
          const isExpanded = Boolean(expandedPosts[post.id]);
          const isLong = post.body.length > 180;
          return (
            <article key={post.id} className="rounded-[6px] border border-[var(--hs-border-subtle)] p-4">
              <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                <h4 className="text-[15px] font-semibold text-[var(--hs-neutral-800)]">{post.title}</h4>
                <span className="text-[12px] text-[var(--hs-neutral-400)]">{formatEnglishDate(post.date)}</span>
              </div>
              <p className={`text-[14px] leading-[1.9] text-[var(--hs-neutral-700)] ${isExpanded ? '' : 'hs-line-clamp-3'}`}>
                {post.body}
              </p>
              {post.attachments?.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {post.attachments.map((file) => (
                    <span
                      key={file}
                      className="rounded-[4px] border border-[var(--hs-border-subtle)] bg-[var(--hs-bg-subtle)] px-2 py-1 text-[12px] text-[var(--hs-neutral-600)]"
                    >
                      {file}
                    </span>
                  ))}
                </div>
              )}
              {isLong && (
                <button
                  type="button"
                  onClick={() => togglePost(post.id)}
                  className="hs-interactive mt-3 text-[12px] font-medium text-[var(--hs-primary-700)] hover:text-[var(--hs-primary-800)] focus-visible:outline-none"
                >
                  {isExpanded ? 'إخفاء' : 'عرض المزيد'}
                </button>
              )}
            </article>
          );
        })}
      </div>
    );
  };

  const renderHomework = () => {
    const homework = subject.homework || [];
    if (!homework.length) {
      return <EmptyState title="لا توجد واجبات" description="لا توجد واجبات مسجلة لهذه المادة." compact />;
    }
    return (
      <div className="space-y-3">
        {homework.map((item) => (
          <article key={item.id} className="rounded-[6px] border border-[var(--hs-border-subtle)] p-4">
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <h4 className="text-[15px] font-semibold text-[var(--hs-neutral-800)]">{item.title}</h4>
              <span
                className={`rounded-full px-2 py-1 text-[11px] font-semibold ${
                  HOMEWORK_STATUS_STYLES[item.status] || 'bg-[var(--hs-bg-muted)] text-[var(--hs-neutral-600)]'
                }`}
              >
                {item.status}
              </span>
            </div>
            <p className="text-[13px] text-[var(--hs-neutral-500)]">
              تاريخ التسليم: {formatEnglishDateTime(item.dueDate)}
            </p>
            {item.attachment ? (
              <p className="mt-1 text-[13px] text-[var(--hs-neutral-600)]">مرفق: {item.attachment}</p>
            ) : null}
            {item.teacherComment && (
              <p className="mt-2 rounded-[4px] bg-[var(--hs-bg-subtle)] px-3 py-2 text-[13px] leading-[1.8] text-[var(--hs-neutral-600)]">
                ملاحظة المعلم: {item.teacherComment}
              </p>
            )}
          </article>
        ))}
      </div>
    );
  };

  const renderTabContent = () => {
    if (activeTab === 'posts') return renderPosts();
    if (activeTab === 'homework') return renderHomework();
    return <GradeTable rows={subject.grades || []} />;
  };

  const summary = {
    homeworkCount: subject.homework?.length || 0,
    averageGrade,
    feedbackCount: subject.feedbackItems?.length || 0,
  };

  return (
    <main dir="rtl" className="hs-theme min-h-screen bg-[var(--hs-bg-base)]">
      {/* Sticky page header */}
      <div className="sticky top-0 z-20 border-b border-[var(--hs-border-subtle)] bg-[var(--hs-bg-base)]">
        <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-12">
          <button
            type="button"
            onClick={onBack}
            aria-label="العودة للوحة الرئيسية"
            className="hs-interactive inline-flex h-9 items-center gap-2 rounded-[6px] border border-[var(--hs-border-subtle)] bg-[var(--hs-bg-base)] px-3 text-[13px] font-medium text-[var(--hs-neutral-600)] hover:bg-[var(--hs-bg-subtle)] hover:text-[var(--hs-neutral-900)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--hs-primary-500)] focus-visible:ring-offset-2 active:scale-[0.98]"
          >
            <BackIcon />
            رجوع
          </button>

          <div className="flex items-center gap-2">
            <span className="hidden text-[13px] text-[var(--hs-neutral-400)] sm:inline">انتقل إلى:</span>
            <SubjectSwitcher
              current={subject}
              allSubjects={allSubjects}
              onSwitch={handleSwitch}
            />
          </div>
        </div>
      </div>

      {/* Page body */}
      <div className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6 lg:px-12">
        {/* Subject header */}
        <header className="mb-8 flex items-start gap-4">
          <div className="flex-shrink-0 overflow-hidden rounded-[6px] border border-[var(--hs-border-subtle)] bg-[var(--hs-bg-subtle)] p-2">
            <img
              src={subject.image}
              alt={subject.name}
              className="h-14 w-14 object-contain"
            />
          </div>
          <div>
            <h1 className="hs-display text-[26px] font-semibold leading-tight text-[var(--hs-neutral-900)]">
              {subject.name}
            </h1>
            <p className="mt-1 text-[14px] text-[var(--hs-neutral-500)]">المعلم: {subject.teacher}</p>
            <p className="mt-0.5 text-[13px] text-[var(--hs-neutral-400)]">
              المتوسط الحالي: {formatEnglishNumber(averageGrade, 1)}%
            </p>
          </div>
        </header>

        {/* Content grid */}
        <div className="grid gap-6 lg:grid-cols-[minmax(0,7fr)_minmax(0,3fr)]">
          <div className="space-y-4">
            <Tabs tabs={TAB_OPTIONS} activeKey={activeTab} onChange={setActiveTab} />
            {renderTabContent()}
          </div>
          <Sidebar summary={summary} recentFeedback={subject.feedbackItems || []} />
        </div>
      </div>
    </main>
  );
}