import EmptyState from './EmptyState';
import { formatEnglishDate, formatEnglishNumber } from '../utils/format';

export default function Sidebar({ summary, recentFeedback = [] }) {
  const metrics = [
    { key: 'homework', label: 'عدد الواجبات', value: formatEnglishNumber(summary?.homeworkCount || 0) },
    { key: 'average', label: 'متوسط الدرجات', value: `${formatEnglishNumber(summary?.averageGrade || 0, 1)}%` },
    { key: 'feedback', label: 'عدد الملاحظات', value: formatEnglishNumber(summary?.feedbackCount || 0) },
  ];

  return (
    <aside className="space-y-4">
      <section className="hs-surface-card p-4">
        <h3 className="mb-3 text-[17px] font-semibold text-[var(--hs-neutral-800)]">ملخص سريع</h3>
        <div className="space-y-2">
          {metrics.map((item) => (
            <div
              key={item.key}
              className="flex items-center justify-between rounded-[6px] border border-[var(--hs-border-subtle)] px-3 py-2"
            >
              <span className="text-[13px] text-[var(--hs-neutral-500)]">{item.label}</span>
              <strong className="text-[15px] font-semibold text-[var(--hs-neutral-900)]">{item.value}</strong>
            </div>
          ))}
        </div>
      </section>

      <section className="hs-surface-card p-4">
        <h3 className="mb-3 text-[15px] font-semibold text-[var(--hs-neutral-800)]">ملاحظات حديثة</h3>
        {!recentFeedback.length ? (
          <EmptyState title="لا توجد ملاحظات" description="لا توجد ملاحظات مرتبطة بهذه المادة." compact />
        ) : (
          <div className="space-y-3">
            {recentFeedback.slice(0, 4).map((item) => (
              <article key={item.id} className="rounded-[6px] border border-[var(--hs-border-subtle)] p-3">
                <p className="text-[13px] font-medium text-[var(--hs-neutral-700)]">{item.category}</p>
                <p className="hs-line-clamp-2 mt-1 text-[12px] leading-[1.8] text-[var(--hs-neutral-500)]">{item.preview}</p>
                <p className="mt-2 text-[11px] text-[var(--hs-neutral-400)]">{formatEnglishDate(item.date)}</p>
              </article>
            ))}
          </div>
        )}
      </section>
    </aside>
  );
}

