import EmptyState from './EmptyState';
import { formatEnglishDate } from '../utils/format';

const CATEGORY_STYLES = {
  أكاديمي: 'bg-[var(--hs-primary-050)] text-[var(--hs-primary-700)]',
  سلوك: 'bg-[var(--hs-amber-100)] text-[var(--hs-amber-600)]',
  واجبات: 'bg-[var(--hs-success-100)] text-[var(--hs-success-600)]',
  أخرى: 'bg-[var(--hs-bg-muted)] text-[var(--hs-neutral-600)]',
};

export default function FeedbackList({ items = [] }) {
  return (
    <section className="hs-surface-card p-5">
      <h2 className="mb-4 text-[18px] font-semibold text-[var(--hs-neutral-800)]">أحدث الملاحظات</h2>

      {!items.length ? (
        <EmptyState title="لا توجد ملاحظات حالياً" description="سيتم عرض أحدث الملاحظات فور توفرها." compact />
      ) : (
        <div className="divide-y divide-[var(--hs-border-subtle)]">
          {items.slice(0, 5).map((item) => (
            <article key={item.id} className="py-3 first:pt-0 last:pb-0">
              <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2">
                <p className="text-[14px] font-semibold text-[var(--hs-neutral-800)]">{item.subjectName}</p>
                <span
                  className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                    CATEGORY_STYLES[item.category] || CATEGORY_STYLES.أخرى
                  }`}
                >
                  {item.category}
                </span>
              </div>
              <p className="hs-line-clamp-2 text-[13px] leading-[1.8] text-[var(--hs-neutral-600)]">{item.preview}</p>
              <p className="mt-1.5 text-[11px] text-[var(--hs-neutral-400)]">{formatEnglishDate(item.date)}</p>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}