import { useEffect, useRef, useState } from 'react';

export default function Tabs({ tabs = [], activeKey, onChange }) {
  const containerRef = useRef(null);
  const tabRefs = useRef({});
  const [indicator, setIndicator] = useState({ left: 0, width: 0 });

  useEffect(() => {
    const updateIndicator = () => {
      const container = containerRef.current;
      const activeTab = tabRefs.current[activeKey];
      if (!container || !activeTab) return;

      const containerRect = container.getBoundingClientRect();
      const activeRect = activeTab.getBoundingClientRect();
      setIndicator({
        left: activeRect.left - containerRect.left,
        width: activeRect.width,
      });
    };

    updateIndicator();
    window.addEventListener('resize', updateIndicator);

    return () => {
      window.removeEventListener('resize', updateIndicator);
    };
  }, [activeKey, tabs]);

  return (
    <div ref={containerRef} className="relative border-b border-[var(--hs-border-subtle)]">
      <div className="flex items-center gap-1">
        {tabs.map((tab) => {
          const isActive = tab.key === activeKey;

          return (
            <button
              key={tab.key}
              type="button"
              ref={(node) => {
                tabRefs.current[tab.key] = node;
              }}
              onClick={() => onChange?.(tab.key)}
              className={`hs-interactive relative px-4 py-3 text-[14px] font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--hs-primary-500)] focus-visible:ring-offset-2 ${
                isActive ? 'text-[var(--hs-neutral-900)]' : 'text-[var(--hs-neutral-500)] hover:text-[var(--hs-neutral-700)]'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>
      <span
        aria-hidden="true"
        className="hs-tab-indicator pointer-events-none absolute bottom-0 h-[2px] rounded-full bg-[var(--hs-primary-600)]"
        style={{
          width: `${indicator.width}px`,
          transform: `translateX(${indicator.left}px)`,
        }}
      />
    </div>
  );
}

