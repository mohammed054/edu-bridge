function BellIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5" aria-hidden="true">
      <path d="M12 3a4 4 0 0 0-4 4v2.2c0 .8-.2 1.6-.7 2.3L6 13.4v1.1h12v-1.1l-1.3-1.9a4.2 4.2 0 0 1-.7-2.3V7a4 4 0 0 0-4-4Z" stroke="currentColor" strokeWidth="1.4" />
      <path d="M10 17a2 2 0 0 0 4 0" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

function SettingsIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5" aria-hidden="true">
      <path
        d="m10.5 3 .4 1.8c.1.4.4.7.8.9.4.1.9.1 1.3 0 .4-.2.7-.5.8-.9L14.2 3m4.3 2.5-1.4 1.2c-.3.3-.5.7-.5 1.1s.2.8.5 1.1c.3.3.7.5 1.1.5h1.8m0 4.2h-1.8c-.4 0-.8.2-1.1.5-.3.3-.5.7-.5 1.1s.2.8.5 1.1l1.4 1.2M14.2 21l-.4-1.8c-.1-.4-.4-.7-.8-.9a2 2 0 0 0-1.3 0c-.4.2-.7.5-.8.9L10.5 21m-4.3-2.5 1.4-1.2c.3-.3.5-.7.5-1.1s-.2-.8-.5-1.1c-.3-.3-.7-.5-1.1-.5H4.7m0-4.2h1.8c.4 0 .8-.2 1.1-.5.3-.3.5-.7.5-1.1s-.2-.8-.5-1.1L6.2 5.5"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
      <circle cx="12" cy="12" r="2.4" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}

function IconButton({ label, children, onClick, badge = 0 }) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="hs-interactive relative inline-flex h-10 w-10 items-center justify-center rounded-[6px] border border-[var(--hs-border-subtle)] bg-[var(--hs-bg-base)] text-[var(--hs-neutral-700)] hover:bg-[var(--hs-bg-subtle)] hover:text-[var(--hs-neutral-900)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--hs-primary-500)] focus-visible:ring-offset-2"
    >
      {children}
      {badge > 0 ? (
        <span className="absolute -top-1 -left-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-[var(--hs-primary-600)] px-1 text-[11px] font-semibold text-white">
          {badge}
        </span>
      ) : null}
    </button>
  );
}

export default function Header({
  studentName,
  className,
  avatarUrl,
  notificationsCount = 0,
  onOpenNotifications,
  onOpenSettings,
  onLogout,
}) {
  return (
    <header className="hs-surface-card hs-fade-up flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
      <div className="flex items-center gap-3">
        <img
          src={avatarUrl}
          alt={`صورة ${studentName}`}
          className="h-12 w-12 rounded-full border border-[var(--hs-border-default)] object-cover"
        />
        <div>
          <p className="text-[15px] font-semibold text-[var(--hs-neutral-900)]">مرحباً، {studentName}</p>
          <p className="text-[13px] text-[var(--hs-neutral-500)]">الصف: {className}</p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <IconButton label="الإشعارات" onClick={onOpenNotifications} badge={notificationsCount}>
          <BellIcon />
        </IconButton>
        <IconButton label="الإعدادات" onClick={onOpenSettings}>
          <SettingsIcon />
        </IconButton>
        <button
          type="button"
          onClick={onLogout}
          className="hs-interactive inline-flex h-10 items-center justify-center rounded-[6px] border border-[var(--hs-border-default)] px-4 text-[13px] font-medium text-[var(--hs-neutral-700)] hover:border-[var(--hs-border-strong)] hover:bg-[var(--hs-bg-subtle)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--hs-primary-500)] focus-visible:ring-offset-2 active:scale-[0.98]"
        >
          تسجيل الخروج
        </button>
      </div>
    </header>
  );
}

