import EmptyState from './EmptyState';
import { formatEnglishDate } from '../utils/format';

const TYPE_STYLES = {
  'موعد نهائي': 'bg-[var(--hs-danger-100)] text-[var(--hs-danger-600)]',
  إعلان: 'bg-[var(--hs-primary-050)] text-[var(--hs-primary-700)]',
  ملف: 'bg-[var(--hs-bg-muted)] text-[var(--hs-neutral-600)]',
  نموذج: 'bg-[var(--hs-amber-100)] text-[var(--hs-amber-600)]',
};

export default function AnnouncementsList({ items = [], featured }) {
  return (
    <section className="hs-surface-card p-5">
      <h2 className="mb-4 text-[18px] font-semibold text-[var(--hs-neutral-800)]">الإعلانات</h2>

      {/* Featured notice */}
      {featured && (
        <div className="mb-4 rounded-[6px] border border-[var(--hs-danger-100)] bg-[var(--hs-danger-100)] p-4">
          <div className="mb-1 flex items-center justify-between gap-2">
            <span className="rounded-full bg-[var(--hs-danger-600)] px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-white">
              {featured.type}
            </span>
            <span className="text-[11px] text-[var(--hs-neutral-500)]">{formatEnglishDate(featured.date)}</span>
          </div>
          <p className="text-[14px] font-semibold text-[var(--hs-neutral-800)]">{featured.title}</p>
          <p className="mt-1 text-[13px] leading-[1.8] text-[var(--hs-neutral-600)]">{featured.description}</p>
        </div>
      )}

      {!items.length ? (
        <EmptyState title="لا توجد إعلانات" description="سيتم نشر الإعلانات الرسمية هنا." compact />
      ) : (
        <div className="divide-y divide-[var(--hs-border-subtle)]">
          {items.map((item) => (
            <article key={item.id} className="py-3 first:pt-0 last:pb-0">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="mb-1 flex items-center gap-2">
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                        TYPE_STYLES[item.type] || 'bg-[var(--hs-bg-muted)] text-[var(--hs-neutral-500)]'
                      }`}
                    >
                      {item.type}
                    </span>
                    <span className="text-[11px] text-[var(--hs-neutral-400)]">{formatEnglishDate(item.date)}</span>
                  </div>
                  <p className="text-[14px] font-medium text-[var(--hs-neutral-800)]">{item.title}</p>
                  <p className="hs-line-clamp-2 mt-0.5 text-[13px] leading-[1.7] text-[var(--hs-neutral-500)]">
                    {item.description}
                  </p>
                </div>
                <button
                  type="button"
                  className="hs-interactive mt-1 flex-shrink-0 rounded-[4px] border border-[var(--hs-border-subtle)] px-2.5 py-1.5 text-[12px] font-medium text-[var(--hs-primary-700)] hover:border-[var(--hs-primary-400)] hover:bg-[var(--hs-primary-050)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--hs-primary-500)] focus-visible:ring-offset-1 active:scale-[0.98]"
                >
                  {item.actionLabel}
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}