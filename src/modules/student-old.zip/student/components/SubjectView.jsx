import { useEffect, useMemo, useState } from 'react';
import EmptyState from './EmptyState';
import GradeTable from './GradeTable';
import Sidebar from './Sidebar';
import Tabs from './Tabs';
import { formatEnglishDate, formatEnglishDateTime, formatEnglishNumber } from '../utils/format';

const TAB_OPTIONS = [
  { key: 'posts', label: 'المنشورات' },
  { key: 'homework', label: 'الواجبات' },
  { key: 'grades', label: 'الدرجات' },
];

const HOMEWORK_STATUS_STYLES = {
  مكتمل: 'bg-[var(--hs-success-100)] text-[var(--hs-success-600)]',
  'غير مكتمل': 'bg-[var(--hs-danger-100)] text-[var(--hs-danger-600)]',
};

const calculateAverage = (grades = []) => {
  if (!grades.length) return 0;

  const totalScore = grades.reduce((sum, item) => sum + Number(item.score || 0), 0);
  const totalOutOf = grades.reduce((sum, item) => sum + Number(item.outOf || 0), 0);
  if (!totalOutOf) return 0;

  return (totalScore / totalOutOf) * 100;
};

export default function SubjectView({ subject }) {
  const [activeTab, setActiveTab] = useState('posts');
  const [expandedPosts, setExpandedPosts] = useState({});

  useEffect(() => {
    setActiveTab('posts');
    setExpandedPosts({});
  }, [subject?.id]);

  const averageGrade = useMemo(() => calculateAverage(subject?.grades || []), [subject?.grades]);

  if (!subject) {
    return (
      <div className="hs-surface-card p-5">
        <EmptyState title="لا توجد مادة محددة" description="اختر مادة لعرض التفاصيل." />
      </div>
    );
  }

  const togglePost = (postId) => {
    setExpandedPosts((current) => ({
      ...current,
      [postId]: !current[postId],
    }));
  };

  const renderPosts = () => {
    const posts = subject.posts || [];

    if (!posts.length) {
      return <EmptyState title="لا توجد منشورات" description="لا توجد منشورات لهذه المادة حالياً." compact />;
    }

    return (
      <div className="space-y-3">
        {posts.map((post) => {
          const isExpanded = Boolean(expandedPosts[post.id]);
          const isLong = post.body.length > 180;

          return (
            <article key={post.id} className="rounded-[6px] border border-[var(--hs-border-subtle)] p-4">
              <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                <h4 className="text-[16px] font-semibold text-[var(--hs-neutral-800)]">{post.title}</h4>
                <span className="text-[12px] text-[var(--hs-neutral-500)]">{formatEnglishDate(post.date)}</span>
              </div>
              <p className={`text-[14px] leading-[1.9] text-[var(--hs-neutral-700)] ${isExpanded ? '' : 'hs-line-clamp-3'}`}>
                {post.body}
              </p>
              {post.attachments?.length ? (
                <div className="mt-3 flex flex-wrap gap-2">
                  {post.attachments.map((file) => (
                    <span
                      key={file}
                      className="rounded-[4px] border border-[var(--hs-border-subtle)] bg-[var(--hs-bg-subtle)] px-2 py-1 text-[12px] text-[var(--hs-neutral-600)]"
                    >
                      {file}
                    </span>
                  ))}
                </div>
              ) : null}
              {isLong ? (
                <button
                  type="button"
                  onClick={() => togglePost(post.id)}
                  className="hs-interactive mt-3 text-[12px] font-medium text-[var(--hs-primary-700)] hover:text-[var(--hs-primary-800)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--hs-primary-500)] focus-visible:ring-offset-2"
                >
                  {isExpanded ? 'إخفاء' : 'عرض المزيد'}
                </button>
              ) : null}
            </article>
          );
        })}
      </div>
    );
  };

  const renderHomework = () => {
    const homework = subject.homework || [];

    if (!homework.length) {
      return <EmptyState title="لا توجد واجبات" description="لا توجد واجبات مسجلة لهذه المادة." compact />;
    }

    return (
      <div className="space-y-3">
        {homework.map((item) => (
          <article key={item.id} className="rounded-[6px] border border-[var(--hs-border-subtle)] p-4">
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <h4 className="text-[16px] font-semibold text-[var(--hs-neutral-800)]">{item.title}</h4>
              <span
                className={`rounded-full px-2 py-1 text-[11px] font-semibold ${
                  HOMEWORK_STATUS_STYLES[item.status] || 'bg-[var(--hs-bg-muted)] text-[var(--hs-neutral-600)]'
                }`}
              >
                {item.status}
              </span>
            </div>
            <p className="text-[13px] text-[var(--hs-neutral-500)]">تاريخ التسليم: {formatEnglishDateTime(item.dueDate)}</p>
            {item.attachment ? (
              <p className="mt-1 text-[13px] text-[var(--hs-neutral-600)]">مرفق: {item.attachment}</p>
            ) : null}
            {item.teacherComment ? (
              <p className="mt-2 rounded-[4px] bg-[var(--hs-bg-subtle)] px-3 py-2 text-[13px] leading-[1.8] text-[var(--hs-neutral-600)]">
                ملاحظة المعلم: {item.teacherComment}
              </p>
            ) : null}
          </article>
        ))}
      </div>
    );
  };

  const renderTabContent = () => {
    if (activeTab === 'posts') return renderPosts();
    if (activeTab === 'homework') return renderHomework();
    return <GradeTable rows={subject.grades || []} />;
  };

  const summary = {
    homeworkCount: subject.homework?.length || 0,
    averageGrade,
    feedbackCount: subject.feedbackItems?.length || 0,
  };

  return (
    <section className="hs-surface-card p-5 sm:p-6">
      <header className="mb-6 border-b border-[var(--hs-border-subtle)] pb-4">
        <h3 className="text-[24px] font-semibold leading-[1.5] text-[var(--hs-neutral-900)]">{subject.name}</h3>
        <p className="mt-1 text-[13px] text-[var(--hs-neutral-500)]">المعلم: {subject.teacher}</p>
      </header>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,7fr)_minmax(0,3fr)]">
        <div className="space-y-4">
          <Tabs tabs={TAB_OPTIONS} activeKey={activeTab} onChange={setActiveTab} />
          {renderTabContent()}
        </div>

        <Sidebar summary={summary} recentFeedback={subject.feedbackItems || []} />
      </div>

      <p className="mt-4 text-[12px] text-[var(--hs-neutral-400)]">
        المتوسط الحالي للمادة: {formatEnglishNumber(averageGrade, 1)}%
      </p>
    </section>
  );
}

