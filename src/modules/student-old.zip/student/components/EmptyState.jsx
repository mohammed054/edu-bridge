export default function EmptyState({ title, description, compact = false }) {
  return (
    <div
      className={`hs-soft-surface mx-auto flex w-full flex-col items-center justify-center text-center ${
        compact ? 'min-h-[140px] p-4' : 'min-h-[180px] p-6'
      }`}
    >
      <div
        aria-hidden="true"
        className="mb-3 h-10 w-10 rounded-full border border-[var(--hs-border-default)] bg-[var(--hs-bg-base)]"
      />
      <h3 className="text-[17px] font-medium leading-[1.7] text-[var(--hs-neutral-700)]">{title}</h3>
      <p className="mt-1 max-w-[280px] text-[13px] leading-[1.8] text-[var(--hs-neutral-500)]">{description}</p>
    </div>
  );
}

