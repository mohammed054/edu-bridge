export default function SubjectCard({ subject, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="hs-interactive hs-lift-hover group flex w-[176px] flex-shrink-0 flex-col rounded-[6px] border border-[var(--hs-border-subtle)] bg-[var(--hs-bg-base)] p-3 text-right shadow-[var(--hs-shadow-subtle)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--hs-primary-500)] focus-visible:ring-offset-2 active:scale-[0.98]"
    >
      {/* Thumbnail */}
      <div className="mb-3 overflow-hidden rounded-[4px] border border-[var(--hs-border-subtle)] bg-[var(--hs-bg-subtle)]">
        <img
          src={subject.image}
          alt={subject.name}
          className="h-[96px] w-full object-contain p-2 transition-transform duration-200 group-hover:scale-[1.04]"
        />
      </div>

      {/* Info */}
      <p className="text-[14px] font-semibold leading-snug text-[var(--hs-neutral-800)]">{subject.name}</p>
      <p className="mt-0.5 text-[12px] text-[var(--hs-neutral-500)]">{subject.teacher}</p>

      {/* Arrow indicator */}
      <div className="mt-3 flex items-center justify-end">
        <span className="text-[11px] font-medium text-[var(--hs-primary-600)] opacity-0 transition-opacity duration-150 group-hover:opacity-100">
          عرض المادة ←
        </span>
      </div>
    </button>
  );
}