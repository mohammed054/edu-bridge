import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchStudentWeeklySchedule } from '../../api/api';
import { useAuth } from '../../core/auth/useAuth';
import './studentPortal.css';

const DAY_LABELS = {
  1: 'الإثنين',
  2: 'الثلاثاء',
  3: 'الأربعاء',
  4: 'الخميس',
  5: 'الجمعة',
};

export default function StudentWeeklySchedulePage() {
  const navigate = useNavigate();
  const { token } = useAuth();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [payload, setPayload] = useState({ className: '', entries: [], schoolDays: [1, 2, 3, 4, 5] });

  useEffect(() => {
    let active = true;

    const loadSchedule = async () => {
      try {
        setLoading(true);
        setError('');
        const response = await fetchStudentWeeklySchedule(token);
        if (!active) {
          return;
        }
        setPayload({
          className: response.className || '',
          entries: response.entries || [],
          schoolDays: response.schoolDays || [1, 2, 3, 4, 5],
        });
      } catch (loadError) {
        if (active) {
          setError(loadError?.message || 'تعذر تحميل الجدول الأسبوعي.');
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    loadSchedule();

    return () => {
      active = false;
    };
  }, [token]);

  const slots = useMemo(() => {
    const values = [...new Set((payload.entries || []).map((item) => `${item.startTime}-${item.endTime}`))];
    return values.sort((left, right) => String(left).localeCompare(String(right)));
  }, [payload.entries]);

  const entryMap = useMemo(() => {
    const map = {};
    (payload.entries || []).forEach((entry) => {
      const key = `${entry.dayOfWeek}-${entry.startTime}-${entry.endTime}`;
      map[key] = entry;
    });
    return map;
  }, [payload.entries]);

  return (
    <main dir="rtl" className="hs-theme min-h-screen bg-[var(--hs-bg-base)]">
      <div className="mx-auto max-w-[1200px] px-4 py-8 sm:px-6 lg:px-12">
        <header className="mb-8 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="hs-display text-[30px] font-semibold text-[var(--hs-neutral-900)]">Weekly Schedule</h1>
            <p className="mt-1 text-[13px] text-[var(--hs-neutral-500)]">
              {payload.className ? `الصف ${payload.className}` : 'الصف غير محدد'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('/student')}
            className="hs-interactive inline-flex h-10 items-center justify-center rounded-[6px] border border-[var(--hs-border-default)] px-4 text-[13px] font-medium text-[var(--hs-neutral-700)] hover:bg-[var(--hs-bg-subtle)]"
          >
            العودة للبوابة
          </button>
        </header>

        {error ? (
          <p className="mb-4 rounded-[6px] border border-[var(--hs-danger-100)] bg-[var(--hs-danger-100)] px-4 py-3 text-[13px] text-[var(--hs-danger-600)]">
            {error}
          </p>
        ) : null}

        {loading ? (
          <section className="grid gap-3">
            <div className="skeleton h-16" />
            <div className="skeleton h-16" />
            <div className="skeleton h-16" />
          </section>
        ) : !payload.entries.length ? (
          <section className="hs-surface-card p-8 text-center">
            <p className="text-[16px] font-medium text-[var(--hs-neutral-800)]">Schedule not yet assigned.</p>
          </section>
        ) : (
          <section className="hs-surface-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full text-right">
                <thead className="bg-[var(--hs-bg-subtle)]">
                  <tr>
                    <th className="px-4 py-3 text-[12px] font-semibold text-[var(--hs-neutral-600)]">الوقت</th>
                    {payload.schoolDays.map((day) => (
                      <th key={day} className="px-4 py-3 text-[12px] font-semibold text-[var(--hs-neutral-600)]">
                        {DAY_LABELS[day] || day}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {slots.map((slot) => {
                    const [startTime, endTime] = slot.split('-');
                    return (
                      <tr key={slot} className="border-t border-[var(--hs-border-subtle)] align-top">
                        <td className="px-4 py-3 text-[13px] font-semibold text-[var(--hs-neutral-700)]">
                          {startTime} - {endTime}
                        </td>
                        {payload.schoolDays.map((day) => {
                          const entry = entryMap[`${day}-${startTime}-${endTime}`];
                          return (
                            <td key={`${day}-${slot}`} className="px-4 py-3">
                              {entry ? (
                                <div className="rounded-[8px] border border-[var(--hs-border-subtle)] bg-[var(--hs-primary-050)] p-3">
                                  <p className="text-[14px] font-semibold text-[var(--hs-neutral-900)]">{entry.subject}</p>
                                  <p className="mt-1 text-[12px] text-[var(--hs-neutral-600)]">{entry.teacherName || '-'}</p>
                                  <p className="mt-1 text-[12px] text-[var(--hs-neutral-500)]">{entry.room || '-'}</p>
                                </div>
                              ) : (
                                <span className="text-[12px] text-[var(--hs-neutral-400)]">-</span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>
        )}
      </div>
    </main>
  );
}
