import arabicImage from '../../../assets/arabic.png';
import biologyImage from '../../../assets/biology.png';
import chemistryImage from '../../../assets/chemistry.png';
import islamicImage from '../../../assets/islamic-studies.png';
import mathImage from '../../../assets/math.png';
import physicsImage from '../../../assets/physics.png';
import socialImage from '../../../assets/social-studies.png';

const SUBJECT_IMAGE_MAP = {
  الرياضيات: mathImage,
  'اللغة العربية': arabicImage,
  الفيزياء: physicsImage,
  الكيمياء: chemistryImage,
  الأحياء: biologyImage,
  'الدراسات الاجتماعية': socialImage,
  'التربية الإسلامية': islamicImage,
};

export const resolveSubjectImage = (subjectName) => SUBJECT_IMAGE_MAP[String(subjectName || '').trim()] || mathImage;
